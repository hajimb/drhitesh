<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'alsalamtechnolog_0' );

/** MySQL database username */
define( 'DB_USER', 'alsalamtechnolog_0' );

/** MySQL database password */
define( 'DB_PASSWORD', 'L5d978@Sp-' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'sekyfcusyk60hivnv4eadr3k46vodvtakrisy6k883pabxjo2vhheedsgnu1qx8l' );
define( 'SECURE_AUTH_KEY',  'r49tdk9fjwvyir6i2mmjpxnydsgbk2nsw6puo5vsg2e9kg4xn2z5kx0ldyfn6tqx' );
define( 'LOGGED_IN_KEY',    'h0yqgyxwppkb5us1jvzrksam9fpdbrbonbhae1fu9j5sy9ot7nmxnekxjnt0bedb' );
define( 'NONCE_KEY',        'hfzdaxtxfucyovfxpcx2aoufeia7hkoaxcustvdhtms8xjyoigetcviakcn9cqnq' );
define( 'AUTH_SALT',        'ypprbjpgt4y3casmbskmdpudhdm6iht6h7fijyr8qfc5d2gdgnov4jircngkxbtq' );
define( 'SECURE_AUTH_SALT', '3i0xkra1v6vtxhvlasgcgohml0skommrselb0ri4lvpjjzevzg8ax7kg9iw2tyyh' );
define( 'LOGGED_IN_SALT',   'ajdm1qdm4xpmwv4cgjo7aqoblcsuekhittcfyvyzkkyd8g9mx95vuyspmcxb2hue' );
define( 'NONCE_SALT',       'jnsl4yrsj9tvp68g638bikb4fxtegksovpd3rpclh5upbcwdeurfn6vo0kmf0vbv' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpoa_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
