# CONTRIBUTING

Dotclear is an open source project. If you'd like to contribute, you can send
a pull request, or feel free to use any other way you'd prefer.

There are many way to contribute :

 * Report bugs (https://dev.dotclear.org/2.0/report and https://dev.dotclear.org/2.0/newticket)
 * Add documentation (https://dotclear.org/documentation/2.0 in English, https://fr.dotclear.org/documentation/2.0 in French)
