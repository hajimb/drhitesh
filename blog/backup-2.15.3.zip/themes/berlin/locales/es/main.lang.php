<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 * @copyright GPL-2.0-only
 */#
#
#
#        DOT NOT MODIFY THIS FILE !




$GLOBALS['__l10n']['Additionnal style directives'] = 'Instrucciones CSS adicionales';
$GLOBALS['__l10n']['reactions'] = 'reacciones';
$GLOBALS['__l10n']['Add ping'] = 'Agregar un retroenlace';
$GLOBALS['__l10n']['From'] = 'Del';
