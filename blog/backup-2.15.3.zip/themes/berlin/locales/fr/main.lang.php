<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 * @copyright GPL-2.0-only
 */#
#
#
#        DOT NOT MODIFY THIS FILE !




$GLOBALS['__l10n']['Additionnal style directives'] = 'Directives CSS supplémentaires';
$GLOBALS['__l10n']['reactions'] = 'réactions';
$GLOBALS['__l10n']['no reactions'] = 'pas de réaction';
$GLOBALS['__l10n']['one reaction'] = 'une réaction';
$GLOBALS['__l10n']['%s reactions'] = '%s réactions';
$GLOBALS['__l10n']['Add ping'] = 'Ajouter un rétrolien';
$GLOBALS['__l10n']['From'] = 'De';
$GLOBALS['__l10n']['Preview'] = 'Prévisualiser';
$GLOBALS['__l10n']['Send'] = 'Envoyer';
$GLOBALS['__l10n']['Show menu'] = 'Montrer le menu';
$GLOBALS['__l10n']['Hide menu'] = 'Cacher le menu';
$GLOBALS['__l10n']['Navigation'] = 'Navigation';
