<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 * @copyright GPL-2.0-only
 */#
#
#
#        DOT NOT MODIFY THIS FILE !




$GLOBALS['__l10n']['From'] = 'Von';
$GLOBALS['__l10n']['Send'] = 'Senden';
$GLOBALS['__l10n']['Add ping'] = 'Ping hinzufügen';
