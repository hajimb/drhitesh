<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 * @copyright GPL-2.0-only
 */#
#
#
#        DOT NOT MODIFY THIS FILE !




$GLOBALS['__l10n']['toDay'] = 'to';
$GLOBALS['__l10n']['FromDay'] = 'From';
