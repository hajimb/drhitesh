<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Register_model extends CI_Model {

	public function __construct(){
		parent::__construct();
	}


	public function newuser($master_user){

			$this->db->trans_begin();
			$isuserexist = $this->isuserexist($master_user);
			if($isuserexist==0){
				$insert		 = $this->db->insert('master_user',$master_user);
				$user_id 	 = $this->db->insert_id();
				$affrows = $this->db->affected_rows();
				if($affrows == 1){

					if ($this->db->trans_status() === FALSE){
					    $this->db->trans_rollback();
					    $result = array("status" => false,"success" => true,"msg" => "Roll back Error","user_id"=>0);
					}
					else{
					    $this->db->trans_commit();
					    $result = array("status" => true,"success" => true,"msg" => "Successfully Registered","user_id"=>$user_id);
					}
				}else{
					$result = array("status" => false,"success" => true,"msg" => "Error While Submitting Registering","user_id"=>0);
				}
			}else{
				$result = array("status" => false,"success" => true,"msg" => "User Already Exists","user_id"=>0);
			}
		return $result;
	}

	public function isuserexist($master_user){

		$query =$this->db->where("contact",$master_user['contact'])->or_where("email",$master_user['email'])->from("master_user")->count_all_results();
		return $query;
	}

	


}
