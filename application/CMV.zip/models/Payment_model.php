<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Payment_model extends CI_Model {
	public function __construct(){
		parent::__construct();
	}

	public function makepayment($master_patient2,$master_patient1,$master_payment,$clinic_payment,$clinic_appointment){
		$this->db->trans_begin();
		$appointment_id = 0;
		if(count($master_patient2) > 0){
	            $insert               = $this->db->insert('patient_master',$master_patient2);
	            $pid                  = $this->db->insert_id();
	            $pad                  = str_pad($pid, 5, "0", STR_PAD_LEFT);
	            $user_name            = $pad;
	            $updata['patient_id'] = $user_name;
	                $this->db->where('id',$pid);
	                $this->db->update('patient_master',$updata);
	        }    
	        
	        $insert               = $this->db->insert('patient_master',$master_patient1);
	        $pid2                 = $this->db->insert_id();
	        $pad                  = str_pad($pid2, 5, "0", STR_PAD_LEFT);
	        $user_name            = $pad;
	        $updata['patient_id'] = $user_name;
	            $this->db->where('id',$pid2);
	            $this->db->update('patient_master',$updata);
		

		$clinic_appointment['patient_id'] = $pid2;
		$clinic_payment['patient_id'] 	  = $pid2;
		$isexists = $this->isappointmentexists($clinic_appointment['start_time'],$clinic_appointment['end_time'],$clinic_appointment['date']);
		if($isexists==0){
			$insert1 = $this->db->insert('master_payment',$master_payment);
			$insert2 = $this->db->insert('clinic_appointment',$clinic_appointment);
			$appointment_id = $this->db->insert_id();
			$clinic_payment['appointment_id'] = $appointment_id;
			$insert3 = $this->db->insert('clinic_payment',$clinic_payment);
			if($this->db->trans_status() === FALSE){
			    $this->db->trans_rollback();
			    $result = array("status" => false,"success" => true,"msg" => "Roll back Error");
			}
			else{
			    $this->db->trans_commit();
			    $result = array("status" => true,"success" => true,"msg" => "Appointment Request");
			}	
			
		}else{
			$result = array("status" => false,"success" => true,"msg" => "Appointment Already Exists");
		}
		return $result;
	}	

	private function isappointmentexists($stime,$etime,$date){
		$array = array('start_time' => $stime, 'end_time' => $etime, 'date' => $date);
		$this->db->from('clinic_appointment'); 
		$this->db->where($array); 
		$query = $this->db->get();
	    return $query->num_rows();
	}
}