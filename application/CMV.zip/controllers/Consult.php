<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Consult extends CI_Controller {
	public function __construct(){
		parent::__construct();
		/*cache control*/
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');
		$this->load->model([
            'website/section_model',
            'website/home_model',
            'website/setting_model'
        ]);$this->load->model('consult_model');
        $this->load->helper('common');
	}

	public function index(){
	    $page_data['heading']    = 'Sexologist';
	    $page_data['pagename']   = 'consult';
	    $page_data['page_title'] = 'consultation | Sexologist';
	    $page_data['page_meta']  = '';
	    $page_data['setting'] 	 = $this->home_model->setting();
		$this->load->view('website/main', $page_data);
	}
	public function online(){
		// print_r($_SESSION);
	    $page_data['heading']    = 'Sexologist';
	    $page_data['pagename']   = 'consult-online';
	    $page_data['page_title'] = 'Consult Online | Sexologist';
	    $page_data['appfor']	 = getappointmentfor($this->session->userdata('user_id'));
	    $page_data['setting'] 	 = $this->home_model->setting();
		$this->load->view('website/main', $page_data);
	}
	public function personally(){
	    $page_data['heading']    = 'Sexologist';
	    $page_data['pagename']   = 'consult-personally';
	    $page_data['page_title'] = 'Consult Personally | Sexologist';
	    $page_data['page_meta']  = '';
	    $page_data['setting'] 	 = $this->home_model->setting();
		$this->load->view('website/main', $page_data);
		
	}
	public function getconsultlist($param1 = '') {
		$param1 =str_replace('_', '-', $param1);
	
        $results = $this->consult_model->getconsultlist($param1);
        $data 	 = array();
		$no 	 = 0;
        foreach ($results  as $r) {
        	$id = $r['id'];
			$no++;
			$row    = array();
			$row[]  = ucwords(strtolower($r['full_name']));
			$row[]  = $r['email'];
			$row[]  = ucwords(strtolower($r['subject']));
			$row[]  = substr(htmlspecialchars_decode($r['message']), 0, 50);
			$row[]  = '<a class="btn btn-info view" data-id="'.$id.'" href="javascript:void(0)" data-modal="'.$r['contact_type'].'"> View</a> <a class="btn btn-danger delete" data-id="'.$id.'" href="javascript:void(0)" data-modal="confirmation"> Delete</a>';
			$data[] = $row;
        }
        echo json_encode(array('data' => $data));
    }

	
}
