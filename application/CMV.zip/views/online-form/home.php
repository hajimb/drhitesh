<?php $this->load->view('online-form/includes/top.php');?>

	<div class="smart-wrap">
    	<div class="smart-forms smart-container wrap-1">
        
            	<?php $this->load->view('online-form/'.$pagename);?>
            
        </div><!-- end .smart-forms section -->
    </div><!-- end .smart-wrap section -->


<?php $this->load->view('online-form/includes/bottom.php');?>