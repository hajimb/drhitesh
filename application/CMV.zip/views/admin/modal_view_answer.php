<h4><?php echo htmlspecialchars_decode($result->question);?></h4>
<div><?php echo htmlspecialchars_decode($result->answer);?></div>
