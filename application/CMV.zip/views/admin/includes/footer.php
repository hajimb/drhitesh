<footer class="main-footer">
    <div class="pull-right"> Design &amp; Maintained By <a href="http://badricomputers.co.in/" target="_blank">Badricomputers</a> </div>
    <strong>
    	Copyright &copy; 2014-2015 <a href="<?php echo base_url();?>" target="_blank">Sexologist.info</a>
    </strong> 
</footer>