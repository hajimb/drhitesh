<div class="clearfix margin_top6"></div>
<div class="featured_div19 featured_section56">
    <div class="container animate fadeInRight professsional" data-anim-type="fadeInRight" data-anim-delay="300" ">
        <h2 class="page-heading text-center ">Payment</h2>
        <div class="row ">
            <div class="col-lg-12 ">
                <div class="separator-holder clearfix text-center ">
                    <div class="separator "></div>
                </div>
            </div>
        </div>
        <div class="row wbg ">
            <div class="col-lg-12 text-center ">
                Thank you 
            </div>
        </div>
    </div>
</div>
