<div class="clearfix"></div>
<!-- <div class="slidermar1 visible-xs">
    <img src="<?php echo base_url();?>assets/img/home-video.png" class="img-responsive">
</div>
 -->
<div class="row">
    <div class="col-lg-12">
        <h2 class="page-heading text-center dgcolor">Rediscover your Love and Passion</h2>
    </div>
    <div class="col-lg-12 text-center">
        <div class="separator"></div>
    </div>
</div>
<div class="banner">
    <img src="<?php echo base_url();?>assets/img/home-video.png" class="img-responsive" style="width: 100%;">
</div>
<div class="featured_div19">
    <div class="container">
        <!-- end div -->
        <p class="text-center animate fadeInUp" data-anim-type="fadeInUp" data-anim-delay="300"><em>You always wanted to be a loving and passionate couple, </em><em>like the one above !<br></em></p>
        <p class="text-center animate fadeInUp" data-anim-type="fadeInUp" data-anim-delay="300"><em>But, find it difficult for your dream from coming true, </em><em>due to sexual and emotional issues!?</em></p>
        <p class="text-center animate fadeInUp" data-anim-type="fadeInUp" data-anim-delay="300"><em>No worry; we are here to provide you with, Effective Sex Solutions!&nbsp;</em></p>
    </div>
</div>
<div class="featured_div19 featured_section56">
    <div class="content_fullwidth">
        <!-- <div class="container"> -->
            <div class="stcode_title8">
                <h2><span class="line"></span><span class="text">We Care For</span></h2>
            </div>
            <!-- end section title heading -->
            <div class="clearfix margin_top3 hidden-xs"></div>
            <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 text-center">
                <h2 class="page-heading size20"><a href="<?php echo base_url();?>men">Men</a></h2>
                <div class="separator"></div>

                <div class="card-container">
                  <div class="card" id="card1">
                    <div class="front">
                        <img src="<?php echo base_url();?>assets/img/men.jpg" class="img-responsive">
                        <div class="clearfix margin_top3"></div>
                        <ul class="arrows_list2 visible-xs">
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Low Sexual Desire</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Erectile Dysfunction</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Premature Ejaculation</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Sexual Addiction</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Compulsive Masturbation</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Phimosis</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Paraphimosis</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Stress</a></li>
                        </ul>
                        <p class="hidden-xs">Low Sexual Desire
                            <br> Erectile Dysfunction
                            <br> Premature Ejaculation
                            <br> Performance Anxiety
                            <br> Sexual Addiction
                            <br> Compulsive Masturbation
                            <br> Phimosis
                            <br> Paraphimosis
                            <br> Stress
                        </p>
                    </div>
                    <div class="back">
                      <img src="<?php echo base_url();?>assets/img/happy-man.png" class="img-responsive">
                      <h3 class="ult-responsive">Empower the man within you</h3>
                      <ul class="arrows_list2 visible-xs">
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Empower sexual self esteem</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Make you feel spontaneous in bed</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Enhance Sensuality</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Maximize performance and pleasure</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Freedom from nervousness and performance anxeity</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Entrusts feeling of being a 'Complete Man'</a></li>
                      </ul>
                      <p class="hidden-xs">Empower sexual self esteem
                          <br> Make you feel spontaneous in bed
                          <br> Enhance Sensuality
                          <br> Maximize performance and pleasure
                          <br> Freedom from nervousness and performance anxeity
                          <br> Entrusts feeling of being a 'Complete Man'</p>
                    </div>
                  </div>
                </div>



            </div>
            <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 text-center martopbot15">
                <h2 class="page-heading size20"><a href="<?php echo base_url();?>women">Women</a></h2>
                <div class="separator"></div>
                <div class="card-container">
                  <div class="card" id="card2">
                    <div class="front">
                        <img src="<?php echo base_url();?>assets/img/women.jpg" class="img-responsive">
                        <div class="clearfix margin_top3"></div>
                        <ul class="arrows_list2 visible-xs">
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Lubrication Disorder</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> (vaginal dryness)</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Penetration Phobia</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Vaginismus</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Narrow vaginal opening</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Lack of Orgasm</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Other Desire Issues</a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Stress</a></li>
                        </ul>
                        <p class="hidden-xs">Lubrication Disorder
                            <br> (vaginal dryness)
                            <br> Penetration Phobia
                            <br> Vaginismus
                            <br> Narrow vaginal opening
                            <br> Lack of Orgasm
                            <br> Other Desire Issues
                            <br> Stress
                        </p>
                    </div>
                    <div class="back">
                      <img src="<?php echo base_url();?>assets/img/happy-women.png" class="img-responsive">
                      <h3 class="ult-responsive">Be the Queen of Your Romance!</h3>
                      <ul class="arrows_list2 visible-xs">
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Empower sexual self esteem</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Make you feel spontaneous in bed</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Enhance Sensuality</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Maximize performance and pleasure</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Freedom from nervousness and inhibitions</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Entrusts feeling of being a 'Complete Woman'</a></li>
                      </ul>
                      <p class="hidden-xs">Empower sexual self esteem
                          <br>Make you feel spontaneous in bed
                          <br>Enhance Sensuality
                          <br>Maximize performance and pleasure
                          <br>Freedom from nervousness and inhibitions
                          <br>Entrusts feeling of being a 'Complete Woman'</p>
                    </div>
                  </div>
                </div>


            </div>
            <!-- end section -->
            <!-- end section -->
            <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 text-center">
                <h2 class="page-heading size20"><a href="<?php echo base_url();?>couple">Couple</a></h2>
                <div class="separator"></div>
                <div class="card-container">
                  <div class="card" id="card3">
                    <div class="front">
                      <img src="<?php echo base_url();?>assets/img/couple.jpg" class="img-responsive">
                      <div class="clearfix margin_top3"></div>
                      <ul class="arrows_list2 visible-xs">
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Non Consummation of Marriage</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Sexual Incompatibility</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Emotional Incompatibility</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Communication Issues</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Sexual Desire Discrepancy</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Art of Foreplay &amp; Lovemaking</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> (Improving Chemistry)</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Position – Posture- Movement guidance</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Extra Marital Affair</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Intimacy Issues</a></li>
                      </ul>
                      <p class="hidden-xs">Non Consummation of Marriage
                          <br> Sexual Incompatibility
                          <br> Emotional Incompatibility
                          <br> Communication Issues
                          <br> Sexual Desire Discrepancy
                          <br> Art of Foreplay &amp; Lovemaking
                          <br> (Improving Chemistry)
                          <br> Position – Posture- Movement guidance
                          <br> Extra Marital Affair
                          <br> Intimacy Issues</p>
                    </div>
                    <div class="back">
                      <img src="<?php echo base_url();?>assets/img/happy-couple.png" class="img-responsive">
                      <h3 class="ult-responsive">Live Life to the Fullest!</h3>
                      <ul class="arrows_list2 visible-xs">
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Enhance Emotional bonding</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Empower Sexual Intimacy</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Boost spontaneity and passion</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Enhance sensuality and romance</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Alchemy for a great couple chemistry</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Achieve highest compatibility</a></li>
                          <li><a href="javascript:void(0)"><i class="fa fa-circle"></i> Whole new meaning to Relationship!</a></li>
                      </ul>
                      <p class="hidden-xs">Enhance Emotional bonding
                          <br> Empower Sexual Intimacy
                          <br> Boost spontaneity and passion
                          <br> Enhance sensuality and romance
                          <br> Alchemy for a great couple chemistry
                          <br> Achieve highest compatibility
                          <br> Whole new meaning to Relationship!</p>
                    </div>
                  </div>
                </div>
            </div>
        <!-- </div-->
    </div>
</div>
<div class="clear"></div>
<div class="featured_div19">
    <div class="container-fluid wbg">
      <h2 class="page-heading text-center">Track Record</h2>
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row text-center martop10">
            <div class="col-lg-4">
                <div class="icon-holder">
                    <i class="fa fa-stethoscope icon-element" aria-hidden="true"></i>
                </div>
                <div class="col-lg-12">
                    <h2 class="page-heading dgcolor">Experience</h2>
                    <div class="separator-holder clearfix">
                        <div class="separator2"></div>
                        <P class="padtop10 text-center">26 Years of Professional Experience</P>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="icon-holder">
                    <i class="fa fa-venus-mars"></i>
                </div>
                <div class="col-lg-12">
                    <h2 class="page-heading dgcolor">Clients</h2>
                    <div class="separator-holder clearfix text-center">
                        <div class="separator2"></div>
                        <P class="padtop10 text-center">More than 20,000+ Satisfied Clients</P>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="icon-holder">
                    <i class="fa fa-lightbulb-o"></i>
                </div>
                <div class="col-lg-12">
                    <h2 class="page-heading dgcolor">Innovations</h2>
                    <div class="separator-holder clearfix text-center">
                        <div class="separator2"></div>
                        <P class="padtop10 text-center">In Clinical Sexology</P>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="featured_div19 featured_section56">
    <div class="container">
        <div class="col-lg-4 animate fadeInLeft" data-anim-type="fadeInLeft" data-anim-delay="300"> <img src="<?php echo base_url();?>assets/img/Dr-hitesh-Shah.jpg" class="img-responsive center">
        </div>
        <div class="col-lg-6 col-lg-push-1 animate fadeInRight" data-anim-type="fadeInRight" data-anim-delay="300">
            <h1> Dr. Hitesh Shah</h1>
            <h3 class="page-heading">A Sexpert in Need, is a Friend Indeed!</h3>
            <p class="general lineheight" style="margin-top:20px;">Dr. Hitesh Shah, an extraordinary blend of Physician and Counsellor, and a Sexologist Par Excellence, classical and top most sexologist in Mumbai, India with clinical experience of 26 years, through his modern scientific exploration, intuitive means, ancient spiritual wisdom and compassion for individual and couple’s suffering, have innovated novel, integrated approaches based on Nature’s principles.</p>
            <p class="general lineheight">Explore your inner journey of healing and achieve physical, emotional, sexual and relationship wellbeing and enrichment, with the help of Dr. Hitesh Shah’s time tested solutions, with which thousands of couples / individuals have been benefited, till the date. <a href="<?php echo base_url();?>about"><b>read more</b></a>
            </p>
        </div>
    </div>
</div>
<div class="container-fluid featured_div19">
    <div class="row text-center wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
        <div class="col-lg-4">
            <div class="col-lg-12">
                <h2 class="page-heading dgcolor size20">Our Approach!</h2>
                <div class="separator-holder clearfix text-center">
                    <div class="separator martop10"></div>
                </div>
            </div>
            <div class="col-lg-12">
                <p class="text-center lineheight28">Caring
                    <br> Artistic
                    <br> Friendly
                    <br> Sensitive
                    <br> Scientific
                    <br> Supportive
                    <br> Empathetic
                    <br> Compassionate
                </p>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="col-lg-12">
                <h2 class="page-heading dgcolor size20">Uniqueness of our service</h2>
                <div class="separator-holder clearfix text-center">
                    <div class="separator martop10"></div>
                </div>
            </div>
            <div class="col-lg-12">
                <p class="text-center lineheight28">Holistic
                    <br> Integrated
                    <br> Personalized
                    <br> Individualistic
                    <br> Concept based
                    <br> Comprehensive
                    <br> Multidisciplinary
                    <br> Online &amp; Face to face</p>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="col-lg-12">
                <h2 class="page-heading dgcolor size20">Speciality of Our Solutions</h2>
                <div class="separator-holder clearfix text-center">
                    <div class="separator martop10"></div>
                </div>
            </div>
            <div class="col-lg-12">
                <p class="text-center lineheight28">Nature based
                    <br> No side effects
                    <br> No dependence
                    <br> Empowering You
                    <br> Nurturing Relations
                    <br> Long term benefits
                    <br> Medicinal &amp; Non Medicinal
                    <br> No short cuts – No quick fixes</p>
            </div>
        </div>
    </div>
</div>

<div class="parallax_section1">
    <div class="container">
        <h2 class="page-heading text-center wcolor">Testimonials</h2>
        <div class="separator"></div>
        <div class="flexslider carousel">
            <div class="flex-viewport">
                <ul class="slides">
                    <li>
                        <h5>Bhoomi</h5>
                        <p>I had severe fear and vaginal spasms which didn't allow my husband to penetrate even after two and a half year of marriage. For conceiving even I could not allow gynecologist to examine me forget allowing the procedure of artificial insemination. Finally our gynecologist referred us to the sexologist Dr. Hitesh Shah. <a href="<?php echo base_url();?>testimonials"><span class="rm">read more</span></a></p>
                    </li>
                    <!-- end slide -->
                    <li>
                        <h5>Leena Arora</h5>
                        <p>I was suffering with severe penetration phobia and what my gynec diagnosed as was vaginismus. Inspite of her treatment when things did not improve, my gynec finally referred me to the sexologist Dr Hitesh Shah..<a href="<?php echo base_url();?>testimonials"><span class="rm">read more</span></a></p>
                    </li>
                    <!-- end slide -->
                    <li>
                        <h5>G M</h5>
                        <p>I was suffering with very low sexual desire and diabetic erectile dysfunction. My wife was passing through terrible frustration. I stopped responding to even 200 mgm of sildenafil and intra penile injections. The best of the andrologists advised me to go for surgery of intra penile implant. But there was risk because of diabetes.<a href="<?php echo base_url();?>testimonials"><span class="rm">read more</span></a></p>
                    </li>
                    <!-- end slide -->
                    <li>
                        <h5>Devashish Jakhad</h5>
                        <p>We are married for four years. Due to various tensions and sexual issues me and my wife were not able to do penetrative sex. I was recommended by one of my friend who was also helped by DR Shah for similar problem. Dr Shah <a href="<?php echo base_url();?>testimonials"><span class="rm">read more</span></a> </p>
                    </li>
                    <!-- end slide -->
                    <li>
                        <h5>Madhur Chauhan</h5>
                        <p>I was suffering with low sperm count and low motility. It did not improve inspire of treatment from my wife's gynecologist, urologist and ayurvedic treatment. After doing a course of six months of treatment with Dr Hitesh Shah.<a href="<?php echo base_url();?>testimonials"><span class="rm">read more</span></a></p>
                    </li>
                    <!-- end slide -->
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"></div>
<?php $this->load->view('website/consultation');?>
