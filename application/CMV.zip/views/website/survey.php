<div class="clearfix margin_top7"></div>

<div class="row">

    <div class="col-lg-12">

        <h2 class="page-heading text-center dgcolor">Surveys</h2>

    </div>

    <div class="col-lg-12 text-center">

        <div class="separator"></div>

    </div>

</div>

<div class="content_fullwidth">

    <div class="container">

        <div class="one_full">

            <div class="address_info">
				<script type='text/javascript'>function zs_open_window(url, height, width){var leftPos = 0;var topPos = 0;if(screen){leftPos = (screen.width - width) / 2;topPos = (screen.height - height) / 2;window.open(url, null, 'width='+width+',height='+height+',left='+leftPos+',top='+topPos+', toolbar=0, location=0, status=1, scrollbars=1, resizable=1');}}</script><a href='https://survey.zohopublic.com/zs/mfCuQa' title='' target='_blank' onclick='zs_open_window(this.href, 648, 700); return false;'>Your Feedback Please </a>

				<!--<script type='text/javascript'>function zs_open_window(url, height, width){var leftPos = 0;var topPos = 0;if(screen){leftPos = (screen.width - width) / 2;topPos = (screen.height - height) / 2;window.open(url, null, 'width='+width+',height='+height+',left='+leftPos+',top='+topPos+', toolbar=0, location=0, status=1, scrollbars=1, resizable=1');}}zs_open_window('https://survey.zohopublic.com/zs/mfCuQa', 648, 700);</script>-->

	            <!--<script>(function(t,e,s,n){var o,a,c;t.SMCX=t.SMCX||[],e.getElementById(n)||(o=e.getElementsByTagName(s),a=o[o.length-1],c=e.createElement(s),c.type="text/javascript",c.async=!0,c.id=n,c.src=["https:"===location.protocol?"https://":"http://","widget.surveymonkey.com/collect/website/js/tRaiETqnLgj758hTBazgd7kUVH_2BT6kl87P5KEhCQYsj5kmiRAJ7EpzNL876dvYWW.js"].join(""),a.parentNode.insertBefore(c,a))})(window,document,"script","smcx-sdk");</script>-->

            </div>

        </div>

    </div>

</div>

<div class="clearfix"></div>

<?php $this->load->view('website/consultation');?>

