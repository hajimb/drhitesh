<div class="clearfix"></div>
<div class="row">
  <div class="col-lg-12">
    <h2 class="page-heading text-center dgcolor">Women</h2>
  </div>
  <div class="col-lg-12 text-center">
    <div class="separator"></div>
  </div>
</div>
<!-- <div class="slidermar1 visible-xs">
    <img src="<?php echo base_url();?>assets/img/women.jpg" class="img-responsive">
</div> -->
<div class="banner">
    <img src="<?php echo base_url();?>assets/img/women.jpg" class="img-responsive" style="width: 100%;">
</div>

<div class="featured_div19">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h2 class="page-heading text-center dgcolor">Am I not a Complete Woman?</h2>
        </div>
        <div class="col-lg-12 text-center">
          <div class="separator"></div>
        </div>
      </div>
        <p class="text-center lineheight28">
            <em>May be,</em>
            <br>
            <em>you are you also passing through similar feelings of Inadequacy, </em>
            <br>
            <em>Incompleteness as a woman, performance anxiety, low self esteem, feeling of unwanted -rejection – non appealing,</em>
            <br>
            <em>low sexual confidence, nervousness, guilt, sexual avoidance behavior, hopelessness, worthlessness and depression? Don’t worry we help you understand your problem and also provide most </em></p>
        <p class="text-center"><em>Effective Sex Solutions…</em></p>
    </div>
</div>

<div class="featured_div19 featured_section81 colored">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <h2 class="page-heading text-center">Effective Solutions for</h2>
        <div class="separator"></div>
        <div class="row">
            <div class="col-lg-3 col-sm-6 col-xs-6 col-md-3 hidden-xs"></div>
            <div class="col-lg-3 col-sm-6 col-xs-6 col-md-3">
                <div class="col-lg-12 text-left">
                    <p class="textexffect lineheight28">
                        <a href="#low-sexual-desire">Low Sexual Desire</a><br>
                        <a href="#sexual-addiction">Sexual Addiction</a><br>
                        <a href="#lubrication-disorder">Lubrication Disorder</a><br>
                        <a href="#delayed-orgasm">Delayed Orgasm</a><br>
                        <a href="#lack-of-orgasm">Lack of Orgasm</a><br>
                        <a href="#impaired-orgasm">Impaired Orgasm</a><br>
                        <a href="#penetration-phobia">Penetration Phobia</a><br>
                        <a href="#vaginismus">Vaginismus</a>
                    </p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-6 col-md-3">
                <div class="col-lg-12">
                    <p class="text-right textexffect lineheight28">
                        <a href="#narrow-vaginal-opening">Narrow Vaginal Opening</a><br>
                        <a href="#vaginal-laxity">Vaginal Laxity</a><br>
                        <a href="#other-desire-issues">Other Desire Issues</a><br>
                        <a href="#unconsummated-marriage">Non Consummated Marriage</a><br>
                        <a href="#stress-and-sex">Stress and Sex</a><br>
                        <a href="#relationship-issue-and-sex">Relationship and Sex</a><br>
                        <a href="#sleep-and-sex">Sleep and Sex</a>
                    </p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-6 col-md-3 hidden-xs"></div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="low-sexual-desire">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Low Sexual Desire</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center pad-top-bot">'My wife is a sex object. Every time I ask for sex, she objects!'. - Les Dawson</h2>
                </div>
            </div>
            <div class="col-lg-9 text-justify">
                <div>
                    <p>Women are very prone and vulnerable to inhibitions, controls, suppressions or retracting into their shell. Also often they need to be loved before submitting oneself to sexual exploration with the partner. No wonder many women remain with ‘low sexual desire’!</p>
                    <p>Also, apart from genetic, hereditary, biological, medical and hormonal factors, in this modern and digital area with varieties of rising levels of stress, relationship issues, stress disorders, medications, addictions and lifestyle issues the incidences of low sexual desire is on phenomenal rise, in todays men.</p>
                    <p>And that’s all the more reason that these complex factors requires highly comprehensive ( evaluation and )approach and not just shots of external testosterone (or any so called ‘aphrodisiacs’ or sex tonics or stimulants) which is always tagged with side effects and has the potential to reduce body’s own capacity to produce natural testosterone.</p>
                    <p>We specialize in going to the root cause of your problem and help you recover with long term and natural, medicinal and non medicinal solutions! Confidential and effective sex solutions for women by renowned sexologist in Mumbai. No side effects. No dependence.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="lubrication-disorder">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Lubrication Disorder</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-9">
                <div>
                    <p class="text-justify lineheight28">Lubrication is physiological counterpart of psychosexual arousal in woman akin to erection in men. Its due to the psychosexual excitement resulting in increased local bood flow in pelvic region and vaginal walls. This shows prepared ness of the woman for sexual act and also gives pleasure. If it is dry, it gives pain.</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                        Lubrication is the spring where pleasure blossoms!
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="penetration-phobia">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Penetration Phobia</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center pad-top-bot">Fear and pleasure, can not exist together!</h2>
                </div>
            </div>
            <div class="col-lg-9 text-justify">
                <div>
                    <p>Lot of young women seek help because of this annoying and frustrating involuntary fear.
                        <br> Common causes:
                        <br> Fear of bleeding
                        <br> Fear of pain
                        <br> Hypersensitive nature to pain. Low pain threshold.
                        <br> Impact of vicarious experiences; shared by someone or seen in movies.
                        <br> Childhood or teenage sex abuse trauma.</p>
                    <p>Because of this the person can not allow partner to insert / penetrate. Couple come to us in miserable state for guidance.</p>
                    <p>The problem can be effectively treated with right guidance and therapy.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="vaginismus">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Vaginismus</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-9">
                <div>
                    <p class="text-justify lineheight28">This is involuntary spasm / contraction of vagina (wall muscles), whenever an attempt at intercourse or examination is made. This is an intense subconscious fear, mostly of injury and pain / bleeding. The woman tends to contract her legs as well and pushes partner awaywhilethe attempt for penetration is made.</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                        Closing the gates and opposing the entry is indicative of sub conscious blocks!
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="narrow-vaginal-opening">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Narrow Vaginal Opening</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center pad-top-bot">A physical obstruction which is solvable without surgery!</h2>
                </div>
            </div>
            <div class="col-lg-9 text-justify">
                <div>
                    <p>A lot many couple face difficulty because the woman has a very narrow opening and partner can not insert the erect penis while attempting for insertion. Most of these cases need dilatation and we help with our innovative approach without surgery.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="lack-of-orgasm">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Lack of Orgasm</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-9">
                <div>
                    <p class="lineheight28">Many women just cant experience climax.
                        <br> Common reasons are:</p>
                    <p class="lineheight28">Very high arousal threshold
                        <br> Inadequate foreplay.
                        <br> Lack of knowledge about erotic zones.</p>
                    </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                       Controls and Inhibitions prevents access to heavenly bliss!
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="unconsummated-marriage">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Unconsummated Marriage</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center pad-top-bot">Married yet virgin, for a reason!</h2>
                </div>
            </div>
            <div class="col-lg-9 text-justify">
                <div>
                    <p>Its not surprising that hundreds of couples have received successful guidance from us for their difficulty of consummation i.e. inability to do peno vaginal penetrative intercourse. We get couple straight from honeymoon on one hand where as many come after one, three, five, ten or even more years of marriage, unconsummated.</p>
                    <p>The reasons for non consummation can be Male factors, female factors, Position – posture – movement factors. Often its a combination of all three categories of factors. We have pioneered the ways to evaluate such a situation and guide the often discouraged, demoralized couple to a smooth and pleasurable start of their sex life.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="stress-and-sex">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Stress and Sex</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-9">
                <div>
                    <p>If you have experienced this nothing more remains to be explained. So simply put, our approach help to destress you where passion and performance can really blossom in you and your relationship.</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                        Less stress more sex. More sex less stress! More stress less sex. Less sex more stress! - Dr. Hitesh Shah
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="relationship-issue-and-sex">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Relationship Issues and Sex</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center pad-top-bot">"Love is the answer, but while you are waiting for the answer, sex raises some pretty good questions." - Woody Allen</h2>
                </div>
            </div>
            <div class="col-lg-9 text-justify">
                <div>
                    <p>Harmony, peace, love, respect, care and affection are essential in a relationship to ignite passion and keep afloat the higher levels of sexual intimacy and joy. Often the relationships are evolving and negative emotions like hurt feelings and ego, anger, sadness, mistrust, insecurity etc takes its toll on sexual desire and performance. Our comprehensive approach primarily evaluates the quality of couples relationship and its impact on their sex life and also helps them enrich their emotional bond!</p>
                    <p class="lineheight28"><i>"We waste time looking for the perfect lover, instead of creating the perfect love."</i></p>
                    <p class="lineheight28">― Tom Robbins</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="sleep-and-sex">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Sleep and Sex</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-9">
                <div>
                    <p>Sleep is an amazing psycho-physiological function which rejuvenates us. This essential part of daily life is most often ignored or taken for granted. Inadequate sleep and sleep disorders are becoming very very common!</p>
                    <p>This affects our emotional well being, mood, physical health as well as our libido and sexual performance. In fact we have produced an awareness film on importance of sleep in our day to day life. <a href="https://www.youtube.com/watch?v=g00Ua2QzNUc" class="textexffect" target="_blank"> <b>Watch Video</b></a>. Sleep, stress and sex are intricately inter influential.</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                        Less stress more sex. More sex less stress! More stress less sex. Less sex more stress! - Dr. Hitesh Shah
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- <div class="featured_div19 featured_section81 colored">
    <div class="container animate" data-anim-type="fadeIn" data-anim-delay="300">
        <h2 class="page-heading text-center">Effective Solution For</h2>
        <div class="separator"></div>
        <?php
            $i=0;
            $html = '';
            echo '<div class="row">';
            foreach ($content as $row){
                $mod = $i%4;
                if($mod==0){
                }?>
            <div class="col-lg-3 col-sm-3 col-md-3 col-xs-6 box effective getdata" data-modal="modal" data-solution="Low Sexual Desire" data-id="<?php echo $row[
            'id'];?>">
                <h4><?php echo $row['title'];?> </h4>
            </div>
            <?php
                if($mod==0){
                }
                $i++;
            } echo '</div>';
        ?>
    </div>
    <div class="featured_section56" id="fdata"></div>
</div> -->
<?php $this->load->view('website/consultation');?>
