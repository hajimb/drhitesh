<div class="clearfix"></div>
<div class="row">
    <div class="col-lg-12">
        <h2 class="page-heading text-center dgcolor">Corporate Stress Management</h2>
    </div>
    <div class="col-lg-12 text-center">
        <div class="separator"></div>
    </div>
    <div class="col-lg-12 text-center">
      <div class="slidermar1">
        <img src="<?php echo base_url();?>assets/img/banners/corporate.jpg" class="img-responsive">
      </div>
    </div>
</div>
<div class="featured_div19">
    <div class="container text-justify animate fadeInLeft" data-anim-type="fadeInLeft" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Corporate Stress Management</h2>
            <div class="col-lg-12">
                <div class="separator-holder clearfix text-center">
                    <div class="separator"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 ">
                <p class="lineheight28 text-center"> 
                	Will Be updating soon
                </p>
            </div>
        </div>
    </div>
</div>
