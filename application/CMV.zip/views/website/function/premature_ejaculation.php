<div class="row">
<h3 class="title29 pad30 mar-bot-0">Performance Anxiety<div class="line"></div></h3>
    <div class="left">
        <div class="col-lg-12">
            <h2>Everything in life is good to achieve quickly and before time, except orgasm!</h2>
        </div>
    </div>
    <!-- end left section -->
    <div class="right">
        <div class="col-lg-12">
                <p class="text-justify">Premature Ejaculation is essentially an early orgasmic response, due to fast pace of excitement, resulting in quick achieving of orgasm and hence ejaculation. It reflects lack of control on force / pace or sexual excitement rather than lack of strength.</p>
                <p class="text-justify">Reasons:</p>
                <p class="text-justify">1. Local hypersensitivity of glans.</p>
                <p class="text-justify">2. Constitutionally many individuals are known to react fast, sexually.</p>
                <p class="text-justify">3. Previous history of masturbation where one is habituated to masturbate to quickly to orgasm; and, then it becomes a self repetitive response pattern in any sexual encounter, too.</p>
                <p class="text-justify">4. Lack of stamina and fitness. Including due to overweight, hypertension and cardiac disorders.</p>
                <p class="text-justify">5. Stress and hurried nature.</p>
                <p class="text-justify">Solution: With our innovative and scientific approach we have made a classic breakthrough, which help you permanently improve and change your fast pace of excitement to a moderate one, which naturally prolongs your timings in each sexual encounter.</p>
        </div>
    </div>
</div>