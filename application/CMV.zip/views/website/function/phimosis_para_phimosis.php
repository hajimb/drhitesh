<div class="row">
<h3 class="title29 pad30 mar-bot-0">Phimosis - Para Phimosis<div class="line"></div></h3>
    <div class="left">
        <div class="col-lg-12">
            <h2>The physical block, most often solvable without surgery!</h2>
        </div>
    </div>
    <!-- end left section -->
    <div class="right">
        <div class="col-lg-11">            
                <p class="lineheight28">Men, and low sexual desire!? Sounds unbelievable, but its true.</p>
                <p class="lineheight28">Apart from genetic, hereditary, biological, medical and hormonal factors, in this modern and digital area with varieties of rising levels of stress, relationship issues, stress disorders, medications, addictions and lifestyle issues the incidences of low sexual desire is on phenomenal rise, in todays men.</p>
                <p class="lineheight28">And that’s all the more reason that these complex factors requires highly comprehensive (evaluation and) approach and not just shots of external testosterone (or any so called ‘aphrodisiacs’ or sex tonics or stimulants) which is always tagged with side effects and has the potential to reduce body’s own capacity to produce natural testosterone.</p>
                <p class="lineheight28">We specialize in going to the root cause of your problem and help you recover with long term and natural, medicinal and non medicinal solutions!</p>
        </div>
    </div>
</div>