<div class="row">
<h3 class="title29 pad30 mar-bot-0">Erectile Dysfunction <div class="line"></div></h3>
    <div class="left">
        <div class="col-lg-12">
            <h2>Only potent thing against love is Impotency!</h2>
        </div>
    </div>
    <!-- end left section -->
    <div class="right">
        <div class="col-lg-11">
                <p class="text-justify lineheight28">Common Reasons:</p>
                <p class="text-justify lineheight28">1. Medical or Organic: Hypertension. Diabetes. High cholesterol and triglycerides. Neurological disorders. Low testosterone. High Prolactin. Hypothyroid with high TSH. Allopathic medicines (antihypertensive, sleep and depression pills, antibiotics, painkillers, anti allergic, antacids, anti lipids etc.), low hemoglobin, Alcohol and Nicotine and other substance abuse.</p>
                <p class="text-justify lineheight28">2. Psychological and situational: Emotional trauma. Mental stress including work and finance related. Performance pressure and anxiety.</p>
                <p class="text-justify lineheight28">There are often combination of all these and other factors in most cases. This requires highly comprehensive evaluation and approach, and not just shots of sildenafil citrate or tadalafil (or any so called ‘aphrodisiacs’ or sex tonics or stimulants) which is always tagged with side effects and dependence and has the potential to reduce body’s own capacity to produce natural erection.</p>
                <p class="text-justify lineheight28">We specialize in going to the root cause of your problem and help you recover with long term and natural, medicinal and non medicinal solutions! Without any side effects or dependence.</p>
        </div>
    </div>
</div>