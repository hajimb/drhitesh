<div class="vc_row wpb_row vc_row-fluid edgtf-section  edgtf-content-aligment-center" style="">
    <div class="clearfix edgtf-full-section-inner">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner ">
                <div class="wpb_wrapper">
                    <div data-edgtf-parallax-speed="1" class="vc_row wpb_row vc_inner vc_row-fluid edgtf-section  edgtf-content-aligment-left" style="">
                        <div class="edgtf-full-section-inner">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="vc_column-inner ">
                                    <div class="wpb_wrapper">
                                        <div class="edgtf-st">
                                            <div class="edgtf-st-inner">
                                                <div class="edgtf-st-title-holder">
                                                    <h2 class="edgtf-st-title" style="text-align: center">
                                                        <span>Communication is the Key</span>
                                                    </h2>
                                                </div>
                                                <div class="edgtf-separator-holder clearfix edgtf-separator-center">
                                                    <div class="edgtf-separator" style="border-color: #ff5744;width: 100px;border-bottom-width: 2px;margin-top: 20px;margin-bottom: 35px"></div>
                                                </div>
                                                <div class="edgtf-st-text-holder" style="text-align: center">
                                                    <span class="edgtf-st-text-text"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-edgtf-parallax-speed="1" class="vc_row wpb_row vc_inner vc_row-fluid edgtf-section vc_custom_1469340760314 edgtf-content-aligment-center" style="">
                        <div class="edgtf-full-section-inner">
                            <div class="wpb_column vc_column_container vc_col-sm-6">
                                <div class="vc_column-inner vc_custom_1469341025689">
                                    <div class="wpb_wrapper">
                                        <a href="<?php echo base_url();?>consult-online" target="_self" style="font-size: 21px;font-weight: 300" class="edgtf-btn edgtf-btn-huge edgtf-btn-solid edgtf-btn-custom-hover-bg edgtf-btn-icon" data-hover-bg-color="#ff5744">
                                            <span class="edgtf-btn-text">Consult Online</span>
                                            <i class="edgtf-icon-font-awesome fa fa-laptop "></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-6">
                                <div class="vc_column-inner vc_custom_1469341041474">
                                    <div class="wpb_wrapper">
                                        <a href="<?php echo base_url();?>consult-personally" target="_self" style="font-size: 21px;font-weight: 200" class="edgtf-btn edgtf-btn-huge edgtf-btn-solid edgtf-btn-custom-hover-bg edgtf-btn-icon" data-hover-bg-color="#ff5744">
                                            <span class="edgtf-btn-text">Consult Personally</span>
                                            <i class="edgtf-icon-font-awesome fa fa-user "></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>