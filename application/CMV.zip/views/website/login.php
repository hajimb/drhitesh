<div class="clearfix margin_top6"></div>
<div class="featured_div19 featured_section56">
    <div class="container animate fadeInRight professsional" data-anim-type="fadeInRight" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Login</h2>
            <div class="col-lg-12">
                <div class="separator-holder clearfix  text-center">
                    <div class="separator"></div>
                </div>
            </div>
        </div>
          <div class="row">
            <form id="loginform" method="post">
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Mobile No./ Email">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                </div>
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 text-center">
                    <!--input type="submit" class="rad0 loginbtn custombtn fbut" value="Login"-->
                    <a href="javascript:void(0)" class="rad0 loginbtn custombtn fbut" style="margin-right:15px">Login</a>
                    <a href="<?php echo base_url();?>register" class="rad0 custombtn fbut">Register</a>
                </div>
            </form>
        </div>
    </div>
</div>
