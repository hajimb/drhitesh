<div class="clearfix"></div>

<div class="col-lg-12 less2">

    <div class="container">

        <div class="row">
            <div class="col-lg-6  col-lg-push-3">

                <div class="address_info">
                    <h4>PURNAM HEALTH CENTRE – Kandivali West</h4>
                    <ul>
                        <li>
                            301, Sanjar Enclave, Above Balaji Banquets, Opp.
                            <br /> Milap PVR Cinema,S.V. Road, Kandivali west,
                            <br /> Mumbai 400067, Maharashtra, India
                            <br /> +91 22 28053555
                            <br /> MON to SAT: 9 am to 9 pm.
                        </li>

                    </ul>

                </div>
            </div>
        </div>
<!--         <div class="col-lg-6">

            <div class="address_info">

                <h4>PURNAM HEALTH CENTRE – Chowpatty</h4>

                <ul>

                    <li>
                        29-A, Dr. Atmaram Ranganekar Marg,

                        <br /> Opp Starbucks, Chowpatty,

                        <br /> Mumbai 400007, Maharashtra, India

                        <br /> +91 98190 35111

                        <br /> By appointment only.

                       </li>

                </ul>

            </div>

        </div> -->
        <div class="row">
            <div class="col-lg-6 col-lg-push-3">

                <div class="address_info">
                    <p class="text-center">
                        Email : <a href="mailto:drhitesh@purnamhealth.com">drhitesh@purnamhealth.com</a> <br>
                        Skype : <a href="skype:drhiteshcounseller?add " style="font-size: 14px "> <img src="<?php echo base_url();?>assets/img/skype.png" alt="Skype call"> drhiteshcounsellor</a> <br>
                        WhatsApp : <a href="whatsapp://send?phone=+919819035111" style="font-size: 14px "> <img src="http://sexologist.purnamhealth.com/assets/img/whatsapp.png" alt="WhatsApp call"> +91 98190 35111</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="clearfix margin_top6"></div>