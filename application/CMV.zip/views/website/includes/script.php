<!-- ######### JS FILES ######### -->
<!-- get jQuery used for the theme -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/universal/jquery.js"></script>
<script type="text/javascript">var base_url = "<?php echo base_url();?>";</script>
<script src="<?php echo base_url();?>assets/js/jquery.toaster.js"></script>
<script src="<?php echo base_url();?>assets/js/style-switcher/styleselector.js"></script>
<script src="<?php echo base_url();?>assets/js/animations/js/animations.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/js/mainmenu/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/mainmenu/customeUI.js"></script>
<script src="<?php echo base_url();?>assets/js/masterslider/jquery.easing.min.js"></script>
<script src="<?php echo base_url();?>assets/js/masterslider/masterslider.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.serializeToJSON.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-datepicker.js?v=v1.2.3"></script>
<?php if($pagename=='consult-online' || $pagename=='consult-personally'){?>
<script src="<?php echo base_url();?>assets/js/bootstrap-datepicker.init.js?v=v1.2.3"></script>
<?php }?>
<script src="<?php echo base_url();?>assets/js/jquery.serializeToJSON.js"></script>
<script src="<?php echo base_url();?>assets/js/shadowbox.js"></script>
<script src="<?php echo base_url();?>assets/js/slider.js"></script>

<script type="text/javascript">

(function($) {
 "use strict";
    var slider = new MasterSlider();
    // adds Arrows navigation control to the slider.
    slider.control('arrows');
    slider.control('bullets');

    slider.setup('masterslider' , {
         width:1400,    // slider standard width
         height:620,   // slider standard height
         space:0,
         speed:40,
         layout:'fullwidth',
         loop:true,
         preload:0,
         autoplay:true,
         view:"parallaxMask",
    });
})(jQuery);

$(window).load(function() {
//      alert("window load occurred!");
    $("#slider-3").slider({
      direction: "left",
       guideSelector: ".guide-other",   // ガイド用クラス名の変更
      cellSelector: ".cell-other"
  });
  Shadowbox.init();
});

$(document).on("click", ".casestudy" , function() {
    var img = $(this).data('img');
    var comment = $(this).data('comment');
    console.log(`img : ${img} comment : ${comment}`)
    $("#csimg").attr("src",img);
    $("#post_by").html(comment);
    $("#cs-img").show();
    if(comment != ''){
      $("#cs-com").show();
    }else{
      $("#cs-com").hide();
    }
});

</script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/velocity/1.2.2/velocity.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/velocity/1.2.2/velocity.ui.min.js'></script>
<script src="<?php echo base_url();?>assets/js/scrolltotop/totop.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/mainmenu/sticky.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/mainmenu/modernizr.custom.75180.js"></script>

<script src="<?php echo base_url();?>assets/js/tabs/assets/js/responsive-tabs.min.js" type="text/javascript"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/cubeportfolio/jquery.cubeportfolio.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/cubeportfolio/main8.js"></script>
<script src="<?php echo base_url();?>assets/js/custom.js"></script>

<script src="<?php echo base_url();?>assets/js/tabs2/index.js"></script>
<script src="<?php echo base_url();?>assets/js/carouselowl/owl.carousel.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/accordion/jquery.accordion.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/accordion/custom.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/universal/custom.js"></script>

<script defer src="<?php echo base_url();?>assets/js/flexslider/jquery.flexslider.js"></script>
<script defer src="<?php echo base_url();?>assets/js/flexslider/custom.js"></script>
<script defer src="<?php echo base_url();?>assets/js/common.js?rand=<?= time();?>"></script>
<script type="text/javascript">
    $(".modal").each(function(l){$(this).on("show.bs.modal",function(l){var o=$(this).attr("data-easein");"shake"==o?$(".modal-dialog").velocity("callout."+o):"pulse"==o?$(".modal-dialog").velocity("callout."+o):"tada"==o?$(".modal-dialog").velocity("callout."+o):"flash"==o?$(".modal-dialog").velocity("callout."+o):"bounce"==o?$(".modal-dialog").velocity("callout."+o):"swing"==o?$(".modal-dialog").velocity("callout."+o):$(".modal-dialog").velocity("transition."+o)})});
    $(".card").click(function() {
      var id = $(this).attr('id');
      $('#' + id).toggleClass('flipped');
    });
    $(".card").hover(function() {
      var id = $(this).attr('id');
      $('#' + id).toggleClass('flipped');
    });
    $(".card").mouseleave(function() {
      var id = $(this).attr('id');
      $('#' + id).toggleClass('flipped');
    });
</script>
