<div class="clearfix"></div>
<div class="row">
    <div class="col-lg-12">
        <h2 class="page-heading text-center dgcolor">Homeopathy</h2>
    </div>
    <div class="col-lg-12 text-center">
        <div class="separator"></div>
    </div>
    <div class="col-lg-12 text-center">
      <div class="slidermar1">
        <img src="<?php echo base_url();?>assets/img/banners/homeopathy.jpg" class="img-responsive">
      </div>
    </div>
</div>
<div class="featured_div19">
    <div class="container text-justify animate fadeInLeft" data-anim-type="fadeInLeft" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Homeopahty </h2>
            <div class="col-lg-12">
                <div class="separator-holder clearfix text-center">
                    <div class="separator"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 ">
                <p class="lineheight28 text-center"> 
                	Treats you as a person and not just the parts<br />
                    Holistic<br />
                    Individualistic<br />
                    No side effects<br />
                    For all chronic physical & psychological diseases & all ages<br />
                    Nature's way to complete wellness <br />
                </p>
                <p class="lineheight28 text-center">
                <a href="http://www.purnamhealth.com/know_homeopathy.php" target="_blank">KNOW ABOUT HOMEOPATHY</a><br /><br />
                
                 <a href="http://www.purnamhealth.com/homeopathy_question.php" target="_blank">QUESTIONNAIRE FORM FOR PATIENT</a><br /><br />
                
                </p>
            </div>
        </div>
    </div>
</div>
