<div class="clearfix"></div>

<!-- <div class="slidermar1 visible-xs">
  <img src="<?php echo base_url();?>assets/img/couple.jpg" class="img-responsive">
</div> -->

<!-- <div class="slidermar1 hidden-xs">
    <div class="master-slider ms-skin-default" id="masterslider">
        <div class="ms-slide slide-3" data-delay="9">
            <div class="slide-pattern"></div>
            <video class="myvideo" poster="<?php echo base_url();?>assets/img/couple.jpg" preload="auto" loop autoplay muted>
                <source type="video/mp4" src="<?php echo base_url();?>assets/video/couple.m4v">
                <object width="320" height="240" type="application/x-shockwave-flash" data="<?php echo base_url();?>assets/js/flashmediaelement.swf">
                    <param name="movie" value="<?php echo base_url();?>assets/js/flashmediaelement.swf" />
                    <param name="flashvars" value="controls=true&amp;file=<?php echo base_url();?>assets/video/couple.m4v" /><img src="<?php echo base_url();?>assets/img/couple.jpg" width="1920" height="800" title="No video playback capabilities" alt="video thumb" /></object>
            </video>
        </div>
    </div>
</div> -->
<div class="banner">
    <img src="<?php echo base_url();?>assets/img/couple.jpg" class="img-responsive" style="width: 100%;">
</div>
<div class="featured_div19">
    <div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-heading text-center dgcolor">Couple</h1>
        </div>
<!--         <div class="col-lg-12 text-center">
            <div class="separator"></div>
        </div>
 -->    </div>
      <div class="row">
        <div class="col-lg-12">
          <h2 class="page-heading text-center dgcolor">Passionless nights and unconnected togetherness!</h2>
        </div>
        <div class="col-lg-12 text-center">
          <div class="separator"></div>
        </div>
      </div>
        <p class="text-center lineheight28">
                <em>May be,</em>
                <br>
                <em>you are you also passing through similar feelings of Inadequacy, Incompleteness as a man, performance anxiety, low self esteem and low sexual confidence, nervousness, avoidance behavior and depression?</em>
                <br>
                <em>Don't worry we help you understand your problem and also provide most</em></p>
            <p class="text-center"> <em>Effective Sex Solution…</em>
            </p>
    </div>
</div>


<div class="featured_div19 featured_section81 colored">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <h2 class="page-heading text-center">Effective Solutions for</h2>
        <div class="separator"></div>
        <div class="row">
            <div class="col-lg-2 col-sm-6 col-md-2 hidden-xs"></div>
            <div class="col-lg-4 col-sm-6 col-xs-12 col-md-4">
                <div class="col-lg-12 text-left">
                     <p class="textexffect lineheight28">
                        <a href="#unconsummated-marriage">Unconsummated Marriage</a><br>
                        <a href="#sexual-incompatibility">Sexual Incompatibility</a><br>
                        <a href="#emotional-incompatibility">Emotional Incompatibility</a><br>
                        <a href="#communication-problems">Communication Problems</a><br>
                        <a href="#extra-marital-affairs">Extra Marital Affairs</a>
                    </p>
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 col-xs-12 col-md-4">
                <div class="col-lg-12 text-right">
                    <p class="textleftxs textexffect lineheight28">
                        <a href="#position-posture-movement-guidence">Position, Posture, Movement Guidance</a><br>
                        <a href="#intimacy-issues">Intimacy Issues</a><br>
                        <a href="#stress-and-sex">Stress and Sex</a><br>
                        <a href="#relationship-issues-and-sex">Relationship and Sex</a><br>
                        <a href="#sleep-and-sex">Sleep and Sex</a>
                    </p>
                </div>
            </div>
            <div class="col-lg-2 col-sm-6 col-md-2 hidden-xs"></div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="sexual-incompatibility">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Sexual incompatibility</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <h2 class="lineheight33 page-heading dgcolor text-center">Feel - Respond - Connect Heart to Heart</h2>
            </div>
            <div class="col-lg-9 parabreak">
                <p>Emotional bonding, intellectual levelheadedness and sexual compatibility are essential for a great companionship and profound intimacy in a couple.</p>
                <p>The sexual compatibility is determined by various factors like desire discrepancy, likes and dislikes (e.g. for oral sex), timing (e.g. night person v/s, morning person), knowledge of erotic zones, openness to experimentation, impact of past psycho sexual trauma or experiences, size mismatch, communication on sexual matters, differential attitudes on matters like porn watching etc.  Feel unconnected and incompatible with your partner? Contact us</p>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="emotional-incompatibility">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Emotional Incompatibility</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align ">
            <div class="col-lg-9 parabreak">
                <div>
                    <p>There are certain strong starting points of a happy emotional bonding like attraction or admiration or feelings for eachother. But, often human relationship passes throuh evolution and experiences roller coaster ride of emotional happiness and sadness, satisfaction and dissatisfaction, fulfillment and frustration.</p>
                    <p>There can be underlying emotional bonding and commitment but at times the emotion tension between two personalities at peak and often it becomes a new disruptive pattern of emotional and communicatioonal disconnect.</p>
                    <p>Such a situation demands lot of patience, self learning, forgiveness, overcoming hurt feelings – hurt ego – blaming states – guilt – prejudices.</p>
                    <p>Its a beautiful journey to undergo counselling and experience freedom from once own negative state and be much more caring, compassionate friendly and loving with the partner. Discovering the higher purpose and trye meaning of relationship itself becomes insightful spiritual journey as well.</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                       Sensitivity. Forgiveness. Affection. Respect. Care. Love.
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="featured_div19 colored" id="communication-problems">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Need to Empathize!</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">Feel - Respond - Connect Heart to Heart</h2>
                </div>
            </div>
            <div class="col-lg-9 parabreak">
                <div>
                    <p>Communication is what connects the Life, meaningfully, Empathy, heart to heart connect, compassion, sensitivity, listening, unselfishness (non self contentedness), non judgmental state, unconditional love and playfulness all makes communication truly harmonious and life, fulfilling. This especially applies to a couple relationship and their intimacy.</p>
                    <p>Plagued with disruptive patterns of communication? Feel strong need to truly connect with partner heart to heart? Ready to learn? Eager to experience harmony and happiness in relationship?</p>
                    <P>I invite you to this beautiful journey of 'love – connect'.</P>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="extra-marital-affairs">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Extra Marital Affair</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row  equal vertical-align">
            <div class="col-lg-9 parabreak">
                <div>
                    <p>Marriage is a beautiful and sacred system of love, intimacy, commitment and companionship. Nevertheless being a (hu)man made system, it is often transgressed under the forces of polygamous attraction due to biological and/ or emotional and / or relationship factors. Every couple relationship or every individual is relatively vulnerable</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                       Destiny or Chemistry or Chance or Choice or Reason?!
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="position-posture-movement-guidence">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Position Posture Movement Guidence</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row  equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">Mechanics are essential to chemistry!</h2>
                </div>
            </div>
            <div class="col-lg-9 parabreak">
                <div>
                    <p>Surprisingly lot of 'armatures' including newly married couples, find it really difficult to adopt right posture to penetrate and / or do the right kind of pelvis thrusting moments resulting into inability to do proper penetrative intercourse. Couple only land up with confusion and nervousness after initial experimentation. This often affect their arousal ( erection in men and lubrication in women) and their overall flow of love making.</p>
                    <p>Come and experience the learning of precise mechanics of how to adopt the right posture, how to enter and how to do pelvic -thrusting movements (in a symbolic ways) and achieve completeness in your sex life.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="intimacy-issues">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Intimacy Issues</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row  equal vertical-align">
            <div class="col-lg-9 parabreak">
                <div>
                    <p>Its human need to be loved and trusted. Its a beautiful feeling to have sense of belonging, with the life partner. Ego melts when you are in love and total 'surrender' happen, while preserving your individuality and space. But, its also in human nature to feel unloved or mistrust!</p>
                    <p>Come and solve all issues pertaining to love, trust, communication, non caring, in-sensitiveness, self contentedness, feeling of rejection. lack of romance and chemistry.</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                       Relationship evolves only if introspection and self learning takes place!
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="stress-and-sex">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Stress and Sex</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">Sex is biggest stress buster</h2>
                </div>
            </div>
            <div class="col-lg-9 parabreak">
                <div>
                    <p>Sex is biggest stress buster.</p>
                    <p>So also, stress can overwhelm an individual and directly or indirectly (through stress disorders like hypertension, diabetes, insomnia, obesity, hyperlipidemia, nicotine and alcohol consumption) affect once libido (desire / passion) and peformance.</p>
                    <p>Todays high paced life rapidly results into stress – burn out state.</p>
                    <p>Many couples, especially if both are working, find it really difficult to cope up with stresses of day to day life issues ( struggle, work pressure ), circumstantial issues (financial, sickness of self or family members) relaionship issues (temperamental, communicational, and communicational), emotional issues etc.</p>
                    <p>To add to it, after initial sexual problems, sexual performance pressure , feeling of inadequacy, frustration piles up affecting sexual functions more badly.</p>
                    <p>There is a way out to experience stress free sex, while building one's coping ability and adaptation!</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="unconsummated-marriage">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Unconsummated Marriage</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-9 parabreak">
                <div>
                    <p>Its not surprising that hundreds of couples have received successful guidance from us for their difficulty of consummation i.e. inability to do peno vaginal penetrative intercourse. We get couple straight from honeymoon on one hand where as many come after one, three, five, ten or even more years of marriage, unconsummated.</p>
                    <p>The reasons for non consummation can be Male factors, female factors, Position – posture – movement factors. Often its a combination of all three categories of factors. We have pioneered the ways to evaluate such a situation and guide the often discouraged, demoralized couple to a smooth and pleasurable start of their sex life.</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                       Married yet virgin, for a reason!
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 colored" id="sleep-and-sex">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Sleep and Sex</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal vertical-align">
            <div class="col-lg-3">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center pad-top-bot">Good sleep - great sex. Good sex - great sleep!</h2>
                </div>
            </div>
            <div class="col-lg-9 parabreak">
                <div>
                    <p>Sleep is an amazing psycho-physiological function which rejuvenates us. This essential part of daily life is most often ignored or taken for granted. Inadequate sleep and sleep disorders are becoming very very common!</p>
                    <p>This affects our emotional well being, mood, physical health as well as our libido and sexual performance. In fact we have produced an awareness film on importance of sleep in our day to day life. <a href="https://www.youtube.com/watch?v=g00Ua2QzNUc" class="textexffect" target="_blank"> <b>Watch Video</b></a>. Sleep, stress and sex are intricately inter influential.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="featured_div19 featured_section81 colored" id="relationship-issues-and-sex">
    <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
        <div class="row">
            <h2 class="page-heading text-center">Relationship Issues and Sex</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
        </div>
        <div class="row equal">
            <div class="col-lg-9 parabreak">
                <div>
                    <p>Harmony, peace, love, respect, care and affection are essential in a relationship to ignite passion and keep afloat the higher levels of sexual intimacy and joy. Often the relationships are evolving and negative emotions like hurt feelings and ego, anger, sadness, mistrust, insecurity etc takes its toll on sexual desire and performance. Our comprehensive approach primarily evaluates the quality of couples relationship and its impact on their sex life and also helps them enrich their emotional bond!</p>
                </div>
            </div>
            <div class="col-lg-3 text-center">
                <div>
                    <h2 class="lineheight33 page-heading dgcolor text-center">
                      "Love is the answer, but while you are waiting for the answer, sex raises some pretty good questions." ― Woody Allen
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- <div class="featured_div19 featured_section81 colored">
    <div class="container animate" data-anim-type="fadeIn" data-anim-delay="300">
        <h2 class="title21">Effective Solution For</h2>
        <?php
            $i=0;
            $html = '';
            echo '<div class="row">';
            foreach ($content as $row){
                $mod = $i%4;
                if($mod==0){
                }?>
            <div class="col-lg-3 col-sm-3 col-md-3 col-xs-6 box effective getdata" data-modal="modal" data-solution="Low Sexual Desire" data-id="<?php echo $row[
            'id'];?>">
                <h4><?php echo $row['title'];?> </h4>
            </div>
            <?php
                if($mod==0){
                }
                $i++;
            } echo '</div>';?>
    </div>
    <div class="featured_section56" id="fdata"></div>
</div> -->


<?php $this->load->view('website/consultation');?>

