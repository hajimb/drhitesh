<div class="clearfix"></div>
    <!-- <div class="slidermar1 visible-xs">
        <img src="<?php echo base_url();?>assets/img/men.jpg" class="img-responsive">
    </div -->
<div class="banner">
    <img src="<?php echo base_url();?>assets/img/men.jpg" class="img-responsive" style="width: 100%;">
</div>
    <div class="featured_div19">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-heading text-center dgcolor">Men</h1>
                </div>
                <!-- <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div> -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-heading text-center dgcolor">Am I a Man Anymore?</h2>
                </div>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <p class="text-center lineheight28">
            <em>May be,</em>
            <br>
            <em>you are also passing through similar feelings of Inadequacy,  </em>
            <br>
            <em>Incompleteness as a man, </em>
            <br>
            <em>performance anxiety, low self esteem and low sexual confidence, </em>
            <br/>
            <em>nervousness, guilt, sexual avoidance behavior,hopelessness, worthlessness and depression? </em>
            </p>
            <p class="text-center">
            <em>Don't worry we help you understand your problem and also provide </em>
            </p>
            <p class="text-center">
            <em>Effective Sex Solution…</em>
            </p>
        </div>
    </div>

    <div class="featured_div19 featured_section81 colored">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <h2 class="page-heading text-center">Effective Solutions for</h2>
            <div class="col-lg-12 text-center">
                <div class="separator"></div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6 col-md-3 hidden-xs"></div>
                <div class="col-lg-3 col-sm-6 col-xs-12 col-md-3">
                    <div class="col-lg-12 text-left">
                        <p class="textexffect lineheight28"><a href="#low-sexual-desire">Low Sexual Desire</a>
                            <br>
                            <a href="#erectile-dysfunction">Erectile Dysfunction</a>
                            <br>
                            <a href="#premature-ejaculation">Premature Ejaculation</a>
                            <br>
                            <a href="#sexual-addiction">Sexual Addiction</a>
                            <br>
                            <a href="#lack-of-orgasm">Lack of Orgasm</a>
                            <br>
                            <a href="#impaired-orgasm">Impaired Orgasm</a>
                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-xs-12 col-md-3">
                    <div class="text-right col-lg-12">
                        <p class="textleftxs textexffect lineheight28"><a href="#performance-anxiety">Performance Anxiety</a>
                            <br>
                            <a href="#phimosis-para-phimosis">Phimosis, Para-Phimosis</a>
                            <br>
                            <a href="#unconsummated-marriage">Non Consummated Marriage</a>
                            <br>
                            <a href="#relationship-issues-and-sex">Relationship and Sex</a>
                            <br>
                            <a href="#stress-and-sex">Stress and Sex</a>
                            <br>
                            <a href="#sleep-and-sex">Sleep and Sex</a></p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-md-3 hidden-xs"></div>
            </div>
        </div>
    </div>

    <div class="featured_div19 colored" id="low-sexual-desire">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Low Sexual Desire</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-3 col-xs-12">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center pad-top-bot">Men, and low sexual desire!? Sounds unbelievable, but its true.</h2>
                    </div>
                </div>
                <div class="col-lg-9 text-justify col-xs-12">
                    <div>
                        <p class="lineheight28">Men, and low sexual desire!? Sounds unbelievable, but its true.</p>
                        <p class="lineheight28">Apart from genetic, hereditary, biological, medical and hormonal factors, in this modern and digital area with varieties of rising levels of stress, relationship issues, stress disorders, medications, addictions and lifestyle issues the incidences of low sexual desire is on phenomenal rise, in todays men.</p>
                        <p class="lineheight28">And that’s all the more reason that these complex factors requires highly comprehensive (evaluation and) approach and not just shots of external testosterone (or any so called ‘aphrodisiacs’ or sex tonics or stimulants) which is always tagged with side effects and has the potential to reduce body’s own capacity to produce natural testosterone.</p>
                        <p class="lineheight28">We specialize in going to the root cause of your problem and help you recover with long term and natural, medicinal and non medicinal solutions!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="featured_div19 featured_section81 colored" id="erectile-dysfunction">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Erectile Dysfunction</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-9">
                    <div>
                        <p class="text-justify lineheight28">Common Reasons:</p>
                        <p class="text-justify lineheight28">1. Medical or Organic: Hypertension. Diabetes. High cholesterol and triglycerides. Neurological disorders. Low testosterone. High Prolactin. Hypothyroid with high TSH. Allopathic medicines (antihypertensive, sleep and depression pills, antibiotics, painkillers, anti allergic, antacids, anti lipids etc.), low hemoglobin, Alcohol and Nicotine and other substance abuse.</p>
                        <p class="text-justify lineheight28">2. Psychological and situational: Emotional trauma. Mental stress including work and finance related. Performance pressure and anxiety.</p>
                        <p class="text-justify lineheight28">There are often combination of all these and other factors in most cases. This requires highly comprehensive evaluation and approach, and not just shots of sildenafil citrate or tadalafil (or any so called ‘aphrodisiacs’ or sex tonics or stimulants) which is always tagged with side effects and dependence and has the potential to reduce body’s own capacity to produce natural erection.</p>
                        <p class="text-justify lineheight28">We specialize in going to the root cause of your problem and help you recover with long term and natural, medicinal and non medicinal solutions! Without any side effects or dependence. <a href="https://www.youtube.com/watch?v=X2Ajmjp53bk" class="textexffect" target="_blank"> <b>Watch Video</b></a></p>
                    </div>
                </div>
                <div class="col-lg-3 text-center">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center">
                            Only potent thing against love is Impotency!
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="featured_div19 colored" id="premature-ejaculation">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Premature Ejaculation</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-3">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center pad-top-bot">Everything in life is good to achieve quickly and before time, except orgasm!</h2>
                    </div>
                </div>
                <div class="col-lg-9 text-justify">
                    <div>
                        <p class="text-justify">Premature Ejaculation is essentially an early orgasmic response, due to fast pace of excitement, resulting in quick achieving of orgasm and hence ejaculation. It reflects lack of control on force / pace or sexual excitement rather than lack of strength.</p>
                        <p class="text-justify">Reasons:</p>
                        <p class="text-justify">1. Local hypersensitivity of glans.</p>
                        <p class="text-justify">2. Constitutionally many individuals are known to react fast, sexually.</p>
                        <p class="text-justify">3. Previous history of masturbation where one is habituated to masturbate to quickly to orgasm; and, then it becomes a self repetitive response pattern in any sexual encounter, too.</p>
                        <p class="text-justify">4. Lack of stamina and fitness. Including due to overweight, hypertension and cardiac disorders.</p>
                        <p class="text-justify">5. Stress and hurried nature.</p>
                        <p class="text-justify">Solution: With our innovative and scientific approach we have made a classic breakthrough, which help you permanently improve and change your fast pace of excitement to a moderate one, which naturally prolongs your timings in each sexual encounter. <a href="https://www.youtube.com/watch?v=KVYlP49f4-0" class="textexffect" target="_blank"> <b>Watch Video</b></a></p>
                    </div>
                </div>
            </div>
        </div>

    <div class="featured_div19 featured_section81 colored" id="performance-anxiety">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Performance Anxiety</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-9">
                    <div>
                        <p class="text-justify">Any problem in erection or condition of premature ejaculation, or even an occasional failure to do proper love making, is perceived a s a blot to manhood!</p>
                        <p class="text-justify">This triggers severe performance pressure and performance anxiety in many men. During their foreplay, instead of being spontaneous and sensuous, they tend to become conscious and nervous. This further takes away their arousal and creates more problem with erection. This escalates anxiety.</p>
                        <p class="text-justify">Thus a vicious circle develops.</p>
                        <p class="text-justify">And, ultimately men start avoiding – thus enters ‘avoidance phase or avoidance behavior’! On other hand the partner also undergoes her misery.</p>
                        <p class="text-justify">Initially she is supportive and keeps patience. But when repeatedly finding herself left high and dry and finding the male partner getting disappointed and embarrassed, ultimately she also suppresses her desire or looses interest.</p>
                        <p class="text-justify">And, as a couple the romance takes back foot and the chemistry goes downhill spiral. Ultimately they loose hope and become frustrated and depressed.</p>
                        <p class="text-justify">There is a classical way to come out of this state and rekindle love, romance and passion. Couple can very soon experience spontaneity and sensuality. And, experience fulfilling sex life.</p>
                        <p class="text-justify">We have specialized and innovated couple therapy solutions and Homeopathic remedies to overcome anxiety and build sexual confidence.</p>
                    </div>
                </div>
                <div class="col-lg-3 text-center">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center">
                            'Performance' and 'Performing' matters a lot to men's sexual self esteem and effects the very core of his manhood!
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="featured_div19 colored" id="phimosis-para-phimosis">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Phimosis - Para Phimosis</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-3">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center">The physical block, most often solvable without surgery!</h2>
                    </div>
                </div>
                <div class="col-lg-9 text-justify">
                    <div>
                        <p class="lineheight28">Phimosis is tight foreskin which can not be retracted back on the glans (head or the front part of the penis) penis.</p>
                        <p class="lineheight28">This creates difficulty during intercourse leading to pain, distraction and loss of erection and most of th time making vaginal penetration (insertion) of penis, impossible. A forceful intercourse can even result in bleeding from frenulum.</p>
                        <p>Generally these cases are advised circumcision. But, we treat phimosis without surgery in 99 % cases unless it a a very very tight foreskin with pin hole opening.</p>
                        <p class="lineheight28">Why its important to preserve foreskin and avoid circumcision:</p>
                        <p class="lineheight28">The rubbing of an elastic and normal foreskin gives a very fine quality of pleasure during intercourse (in and out movement of penis leads the rubbing of foreskin on the glans penis).</p>
                        <p class="lineheight28">Paraphimosis is a condition where, when the foreskin is retracted back but can not be put back to original place. This leads to severe swelling and other severe complications. Generally this is a surgical emergency but most of such cases we treat without surgery through our innovative approach and help person to preserve foreskin which is an excellent source of fine pleasure.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="featured_div19 featured_section81 colored" id="unconsummated-marriage">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Unconsummated Marriage</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-9">
                    <div>
                        <p class="lineheight28">Its not surprising that hundreds of couples have received successful guidance from us for their difficulty of consummation i.e. inability to do peno vaginal penetrative intercourse. We get couple straight from honeymoon on one hand where as many come after one, three, five, ten or even more years of marriage, unconsummated.</p>
                        <p class="lineheight28">The reasons for non consummation can be Male factors, female factors, Position – posture – movement factors. Often its a combination of all three categories of factors. We have pioneered the ways to evaluate such a situation and guide the often discouraged, demoralized couple to a smooth and pleasurable start of their sex life.</p>
                    </div>
                </div>
                <div class="col-lg-3 text-center">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center">Married yet virgin, for a reason! </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="featured_div19 colored" id="stress-and-sex">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Stress and Sex</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-3">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center">Less stress more sex. More sex less stress! More stress less sex. Less sex more stress!</h2>
                    </div>
                </div>
                <div class="col-lg-9 text-justify">
                    <div>
                        <p class="lineheight28">If you have experienced this nothing more remains to be explained. So simply put, our approach help to distress you where passion and performance can really blossom in you and your relationship.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="featured_div19 featured_section81 colored" id="sleep-and-sex">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Sleep and Sex</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-9">
                    <div>
                        <p class="lineheight28">Sleep is an amazing psycho-physiological function which rejuvenates us. This essential part of daily life is most often ignored or taken for granted. Inadequate sleep and sleep disorders are becoming very very common!</p>
                        <p class="lineheight28">This affects our emotional well being, mood, physical health as well as our libido and sexual performance. In fact we have produced an awareness film on importance of sleep in our day to day life. <a href="https://www.youtube.com/watch?v=g00Ua2QzNUc" class="textexffect" target="_blank"> <b>Watch Video</b></a>. Sleep, stress and sex are intricately inter influential.</p>
                    </div>
                </div>
                <div class="col-lg-3 text-center">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center">Good sleep - great sex. Good sex - great sleep! </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="featured_div19 colored" id="relationship-issues-and-sex">
        <div class="container animate fadeIn" data-anim-type="fadeIn" data-anim-delay="300">
            <div class="row">
                <h2 class="page-heading text-center">Realtionship Issues and Sex</h2>
                <div class="col-lg-12 text-center">
                    <div class="separator"></div>
                </div>
            </div>
            <div class="row equal vertical-align">
                <div class="col-lg-3">
                    <div>
                        <h2 class="lineheight33 page-heading dgcolor text-center">"Love is the answer, but while you are waiting for the answer, sex raises some pretty good questions." ― Woody Allen</h2>
                    </div>
                </div>
                <div class="col-lg-9 text-justify">
                    <div>
                        <p class="lineheight28">Harmony, peace, love, respect, care and affection are essential in a relationship to ignite passion and keep afloat the higher levels of sexual intimacy and joy. Often the relationships are evolving and negative emotions like hurt feelings and ego, anger, sadness, mistrust, insecurity etc takes its toll on sexual desire and performance. Our comprehensive approach primarily evaluates the quality of couples relationship and its impact on their sex life and also helps them enrich their emotional bond!.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- <div class="featured_div19 featured_section81 colored">
        <div class="container animate" data-anim-type="fadeIn" data-anim-delay="300">
            <h2 class="page-heading text-center">Effective Solution For</h2>
            <div class="separator"></div>
            <?php
                $i=0;
                $html = '';
                echo '<div class="row">';
                foreach ($content as $row){
                    $mod = $i%4;
                    if($mod==0){
                    }?>
                <div class="col-lg-3 col-sm-3 col-md-3 col-xs-6 box effective getdata" data-modal="modal" data-solution="Low Sexual Desire" data-id="
                    <?php echo $row['id'];?>">
                    <h4>
                        <?php echo $row['title'];?>
                    </h4>
                </div>
                <?php
                    if($mod==0){
                       echo '</div>';
                    }
                    $i++;
                } echo '</div>';
            ?>
        </div>
        <div class="featured_section56" id="fdata"></div>
    </div> -->
   
<?php $this->load->view('website/consultation');?>