<section class="container-fluid dark-color text-center footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4"></div>
                <div class="col-lg-4">
                    <p class="text-center size12"> © Copyright 2016 - sexologist.info, Dr. Hitesh Shah</p>
                </div>
                <div class="col-lg-4 text-right">
                    <a href="https://facebook.com/drhiteshshah" target="_blank">
                        <i class="fa fa-facebook"></i> </a>
                    <a href="https://twitter.com/sexologisttwitt" target="_blank">
                        <i class="fa fa-twitter"></i> </a>
                    <a href="https://linkedin.com/in/drhitesh" target="_self">
                        <i class="fa fa-linkedin"></i> </a>
                    <a href="https://plus.google.com/u/0/" target="_self">
                        <i class="fa fa-google-plus"></i> </a>
                    <a href="mailto:drhiteshshah@gmail.com" target="_self">
                        <i class="fa fa-envelope"></i> </a>
                    <a href="https://www.youtube.com/watch?v=g00Ua2QzNUc'" target="_self">
                        <i class="fa fa-youtube"></i> </a>
                </div>
            </div>
        </div>
    </section>