<section class="container-fluid wbg">
    <h2 class="page-heading text-center">Login</h2>
    <div class="row">
        <div class="col-lg-12">
            <div class="separator-holder clearfix text-center">
                <div class="separator"></div>
            </div>
        </div>
    </div>
</section>
<section class="container-fluid greybg">
    <div class="container">
        <div class="row">
            <form id="loginform" method="post">
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Mobile No./ Email">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                </div>
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 text-center">
                    <input type="submit" class="rad0 loginbtn custombtn" value="Login">
                </div>
            </form>
        </div>
    </div>
</section>